class Node:
    pass


class LinkedList:
    pass


def load_datebase(ds: LinkedList):
    # 파일의 데이터를 읽어 Node 객체에 저장하고
    # Node를 LinkedList에 추가
    pass


def reserve_product(ds: LinkedList):
    # 사용자로부터 정보를 입력 받아 Node를 구성
    # Node를 LinkedList의 끝(root에서 가장 먼 곳)에 추가
    pass

def ship_product(ds: LinkedList):
    # LinkedList의 가장 앞단의 Node를 제거
    pass

def search_customer(ds: LinkedList):
    # 사용자로부터 정보를 입력 받아 LinkedList에 탐색 후 결과 출력
    pass


def remove_customer(ds: LinkedList):
    # 입력된 고객 정보를 포함하는 Node를 LinkedList에서 제거
    pass


def write_datebase(ds: LinkedList):
    # ds에 저장된 데이터를 파일로 저장
    pass


# -----------------------------------------------------------------------------
# 프로그램의 시작

ds = LinkedList()

load_datebase(ds)

while True:
    print("-------------------------------------------")
    print("   대  기  인  원  관  리  프  로  그  램   ")
    print("-------------------------------------------\n")
    print("1) 구매 예약")
    print("2) 제품 출고")
    print("3) 예약 삭제")
    print("4) 예약 검색")
    print("5) 종료")

    select = input("> ")

    if select == "1":
        reserve_product(ds)
    elif select == "2":
        ship_product(ds)
    elif select == "3":
        remove_customer(ds)
    elif select == "4":
        search_customer(ds)
    else:
        break

write_datebase(ds)